# QuickFire

## Unity game embeded in Symfony web page
---
### Instructions

We have embeded a web app in a symfony project, the game itself
is hosted on my github, at [www.meandyy.github.io](https://www.meandyy.github.io "Game hosted here").
WebGL was used to build the game for web.

* Clone this repository and point webserver to the **web** folder.
* In **Mozilla Firefox** search bar type in **'localhost/app_dev.php**.

## **Chrome does not support Unity, therefore use Firefox**

